# ChemDB 前端 UI V3

这是现有 ChemDB Windows 客户端的前端替换版本。它继续使用原项目中的
`config.py` 与 `ssh_http.py`，不修改 API、数据库和 SSH 通道逻辑。

## 主要变化

- 将界面重构为“实验记录 / 记录详情与附件 / 关系思维导图”三栏工作台
- 左右分栏、详情与附件上下分栏均可拖动，正文会按可用宽度自动换行
- 将旧数据正文第一行显示为“实验标题”，保存时仍写回原 `text` 字段
- 正文支持字体、字号、粗体、下划线、文字颜色和荧光标记
- 阅读缩放支持 80%–180%，只改变显示大小，不改变文档中保存的字号
- 富文本格式会随记录保存并在团队客户端中恢复；正文纯文字仍可被原搜索接口检索
- 自动从所有记录的标题与正文识别物质关系，并生成圆形节点与连线思维导图
- 当前记录中的核心物质自动居中，相关实验的相邻物质会一并展示
- 使用表格显示附件名称、类型和大小
- 加入搜索防抖、空状态、异步操作提示和错误提示
- 切换记录或退出时会提醒尚未保存的正文与格式修改
- 原生适配 Windows 100%–250% 高 DPI 缩放，避免系统位图拉伸造成文字发虚
- 重新划分品牌、标题、正文、表格和辅助信息的字号与行高层级
- 支持 `Ctrl+N` 新建、`Ctrl+S` 保存、`Ctrl+F` 搜索、`F5` 刷新
- 仅使用 Tkinter/ttk 与项目原有 Pillow，不增加新的 UI 库依赖

## 接入现有项目

把新版 `main.py` 放到原客户端源码目录，和下面两个已有模块放在一起：

```text
client/
├─ main.py          # 本次新版
├─ config.py        # 沿用原文件，不要提交到公开仓库
└─ ssh_http.py      # 沿用原文件
```

先直接运行验证：

```bash
python main.py
```

没有连接服务器时，可查看本地演示数据：

```bash
python main.py --demo
```

新版会自动读取 Windows 的显示缩放比例。顶部“界面 A− / A+”可以随时改变
整个软件的字号，并自动记住选择。也可通过命令行覆盖（支持 `0.9` 到 `1.4`）：

```bash
python main.py --demo --font-scale 1.15
```

正式连接后端时同样可以使用，例如 `python main.py --font-scale 1.1`。

## 可拖动布局

- 拖动左侧分隔线：调整实验记录与详情区域的宽度
- 拖动右侧分隔线：调整详情区域与思维导图的宽度
- 拖动中央横向分隔线：调整正文编辑器与附件区域的高度
- 拖动任意分隔线后，正文自动重新换行，思维导图自动重新计算圆圈位置

## 富文本格式的保存方式

后端接口仍只接收原来的 `text` 字段。V3 会把可检索的纯正文照常保存在前面，
再在正文末尾附加一个紧凑的 `CHEMDB_RICH_V1` 格式块；新版客户端读取时会隐藏
该格式块并恢复文字样式。因此 API、数据库表和标题/正文搜索均无需修改。

团队成员应统一换用 V3 客户端。旧客户端虽然不会破坏数据，但打开经过富文本保存的
记录时，可能会在正文末尾看到格式块。

## 关系识别约定

当前版本在本地自动识别常见关系表达，不上传正文到第三方服务。推荐使用清晰句式：

```text
亚甲基蓝与铅离子发生吸附。
物质 A 与物质 B 发生反应，物质 B 与物质 C 发生络合。
催化剂 X 对染料 Y 的催化降解。
```

目前识别的关系词包括反应、吸附、降解、催化、光催化、络合、沉淀、氧化、
还原和去除。它适合大创演示与规范实验记录；如果以后要理解省略主语、代词或非常
自由的长段落，建议再由后端增加化学实体识别模型，并继续向前端返回同样的
`source / target / label` 关系结构。

## 打包示例

请在原项目已经能正常打包的 Python 3.10 环境中执行。若原项目已有 `.spec`
文件，优先沿用原命令，只替换 `main.py`。

```bash
pyinstaller --noconfirm --clean --windowed --name chemDb-client main.py
```

如配置和连接模块未被 PyInstaller 自动收集，可显式添加：

```bash
pyinstaller --noconfirm --clean --windowed --name chemDb-client \
  --hidden-import=config --hidden-import=ssh_http main.py
```

## 后端兼容约定

新版界面调用的客户端方法与旧版一致：

- `connect()` / `close()` / `health()`
- `list_entries(q, limit, offset)` / `get_entry(entry_id)`
- `create_entry(text, file_paths)` / `update_entry(entry_id, text)`
- `delete_entry(entry_id)`
- `add_attachments(entry_id, file_paths)`
- `delete_attachment(att_id)` / `download_attachment(att_id)` / `get_thumb(att_id)`

记录字典继续使用 `id`、`text`、`attachments`；附件继续使用 `id`、
`filename`、`size`、`has_thumb`。

## 凭据说明

新版没有复制或写入任何现有 SSH 私钥、API Token。正式发布时仍建议把长期
凭据移出客户端安装包，改用登录认证与可撤销的短期访问凭证。
