import importlib.util
import sys
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).with_name("main.py")
SPEC = importlib.util.spec_from_file_location("chemdb_main_for_tests", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class CoreTests(unittest.TestCase):
    def test_relationship_chain(self):
        entries = [
            {
                "id": 14,
                "text": "关系测试\n物质A与物质B发生反应，物质B与物质C发生吸附，物质A与物质C发生络合。",
            }
        ]
        relations = MODULE.ChemDBApp._extract_relations_from_entries(entries)
        self.assertEqual(
            [(item.source, item.target, item.label) for item in relations],
            [
                ("物质A", "物质B", "反应"),
                ("物质B", "物质C", "吸附"),
                ("物质A", "物质C", "络合"),
            ],
        )

    def test_relationship_in_title_and_body(self):
        entries = [
            {"id": 1, "text": "亚甲基蓝与铅离子吸附实验\n记录不同 pH 条件。"},
            {"id": 2, "text": "正文识别\n刚果红对催化剂的光催化。"},
        ]
        relations = MODULE.ChemDBApp._extract_relations_from_entries(entries)
        self.assertEqual(len(relations), 2)
        self.assertEqual(relations[0].label, "吸附")
        self.assertEqual(relations[1].label, "光催化")

    def test_rich_payload_round_trip(self):
        payload = {
            "version": 1,
            "styles": [
                {
                    "style": {
                        "face": "微软雅黑",
                        "size": 18,
                        "bold": True,
                        "underline": True,
                        "foreground": "#123456",
                        "highlight": "#FFF2A8",
                    },
                    "ranges": [[0, 4]],
                }
            ],
        }
        encoded = "实验正文" + MODULE.RICH_MARKER + MODULE.ChemDBApp._encode_payload(payload) + MODULE.RICH_END
        body, decoded = MODULE.ChemDBApp._decode_rich_body(encoded)
        self.assertEqual(body, "实验正文")
        self.assertEqual(decoded, payload)
        self.assertEqual(MODULE.ChemDBApp._split_text("标题\n" + encoded), ("标题", "实验正文"))

    def test_plain_text_compatibility(self):
        text = "旧版标题\n旧版正文保持不变。"
        self.assertEqual(MODULE.ChemDBApp._split_text(text), ("旧版标题", "旧版正文保持不变。"))


if __name__ == "__main__":
    unittest.main()
