import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DATA_DIR = os.environ.get("CHEMDB_DATA", os.path.join(BASE_DIR, "data"))
FILES_DIR = os.path.join(DATA_DIR, "files")
THUMBS_DIR = os.path.join(DATA_DIR, "thumbs")
DB_PATH = os.path.join(DATA_DIR, "chemdb.db")

# API 鉴权 token，生产环境用环境变量 CHEMDB_TOKEN 覆盖
API_TOKEN = os.environ.get("CHEMDB_TOKEN", "demo-token-change-me")

# 单个附件大小上限（MB）
MAX_UPLOAD_MB = int(os.environ.get("CHEMDB_MAX_UPLOAD_MB", "50"))

# 缩略图最长边（像素）
THUMB_MAX_SIZE = 320

# 只监听本机，外部只能通过 SSH 通道访问
HOST = os.environ.get("CHEMDB_HOST", "127.0.0.1")
PORT = int(os.environ.get("CHEMDB_PORT", "8000"))

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}
