"""chemDb 服务端 HTTP API。

只监听 127.0.0.1，客户端通过 SSH 通道访问。
所有请求需要 Header: Authorization: Bearer <token>
"""

import io
import os
import re
import urllib.parse
import uuid

from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse
from PIL import Image

from . import config, db

app = FastAPI(title="chemDb", docs_url=None, redoc_url=None)


def auth(authorization: str = Header(default="")):
    if authorization != f"Bearer {config.API_TOKEN}":
        raise HTTPException(status_code=401, detail="unauthorized")


@app.on_event("startup")
def startup():
    db.init()


def entry_dict(entry):
    return {
        "id": entry["id"],
        "text": entry["text"],
        "created_at": entry["created_at"],
        "updated_at": entry["updated_at"],
        "attachments": [att_dict(a) for a in db.list_attachments(entry["id"])],
    }


def att_dict(a):
    return {
        "id": a["id"],
        "filename": a["filename"],
        "mime": a["mime"],
        "size": a["size"],
        "has_thumb": bool(a["has_thumb"]),
    }


def is_image(filename, mime):
    ext = os.path.splitext(filename)[1].lower()
    return ext in config.IMAGE_EXTS or mime.startswith("image/")


_PCT_RE = re.compile(r"^(?:[0-9A-Za-z._+-]|%[0-9A-Fa-f]{2})+$")


def _decode_filename(name):
    """客户端 multipart 把非 ASCII 文件名做了百分号编码，这里还原。"""
    if "%" in name and _PCT_RE.match(name):
        return urllib.parse.unquote(name)
    return name


def save_upload(entry_id, uf: UploadFile):
    filename = _decode_filename(uf.filename or "file")
    data = uf.file.read()
    if len(data) > config.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"附件超过 {config.MAX_UPLOAD_MB}MB 限制: {filename}")
    ext = os.path.splitext(filename)[1].lower()
    stored_name = uuid.uuid4().hex + ext
    with open(os.path.join(config.FILES_DIR, stored_name), "wb") as f:
        f.write(data)
    mime = uf.content_type or "application/octet-stream"
    has_thumb = False
    if is_image(filename, mime):
        try:
            img = Image.open(io.BytesIO(data))
            img = img.convert("RGB")
            img.thumbnail((config.THUMB_MAX_SIZE, config.THUMB_MAX_SIZE))
            img.save(os.path.join(config.THUMBS_DIR, stored_name + ".jpg"), quality=80)
            has_thumb = True
        except Exception:
            has_thumb = False
    att_id = db.add_attachment(
        entry_id, filename, mime, len(data), stored_name, has_thumb
    )
    return db.get_attachment(att_id)


def remove_files(stored_names):
    for name in stored_names:
        for path in (
            os.path.join(config.FILES_DIR, name),
            os.path.join(config.THUMBS_DIR, name + ".jpg"),
        ):
            try:
                os.remove(path)
            except FileNotFoundError:
                pass


@app.get("/api/health", dependencies=[Depends(auth)])
def health():
    return {"ok": True}


@app.post("/api/entries", status_code=201, dependencies=[Depends(auth)])
def create_entry(text: str = Form(...), files: list[UploadFile] = File(default=[])):
    if not text.strip():
        raise HTTPException(status_code=400, detail="文字内容不能为空")
    entry_id = db.create_entry(text)
    try:
        for uf in files:
            save_upload(entry_id, uf)
    except Exception:
        stored = [a["stored_name"] for a in db.list_attachments(entry_id)]
        db.delete_entry(entry_id)
        remove_files(stored)
        raise
    return entry_dict(db.get_entry(entry_id))


@app.get("/api/entries", dependencies=[Depends(auth)])
def list_entries(q: str = "", limit: int = 50, offset: int = 0):
    return [entry_dict(e) for e in db.search_entries(q, limit, offset)]


@app.get("/api/entries/{entry_id}", dependencies=[Depends(auth)])
def get_entry(entry_id: int):
    entry = db.get_entry(entry_id)
    if entry is None:
        raise HTTPException(status_code=404, detail="记录不存在")
    return entry_dict(entry)


@app.put("/api/entries/{entry_id}", dependencies=[Depends(auth)])
def update_entry(entry_id: int, text: str = Form(...)):
    if not text.strip():
        raise HTTPException(status_code=400, detail="文字内容不能为空")
    if not db.update_entry(entry_id, text):
        raise HTTPException(status_code=404, detail="记录不存在")
    return entry_dict(db.get_entry(entry_id))


@app.delete("/api/entries/{entry_id}", dependencies=[Depends(auth)])
def delete_entry(entry_id: int):
    stored = db.delete_entry(entry_id)
    if stored is None:
        raise HTTPException(status_code=404, detail="记录不存在")
    remove_files(stored)
    return {"ok": True}


@app.post("/api/entries/{entry_id}/attachments", status_code=201, dependencies=[Depends(auth)])
def add_attachments(entry_id: int, files: list[UploadFile] = File(...)):
    if db.get_entry(entry_id) is None:
        raise HTTPException(status_code=404, detail="记录不存在")
    return [att_dict(save_upload(entry_id, uf)) for uf in files]


@app.delete("/api/attachments/{att_id}", dependencies=[Depends(auth)])
def delete_attachment(att_id: int):
    stored = db.delete_attachment(att_id)
    if stored is None:
        raise HTTPException(status_code=404, detail="附件不存在")
    remove_files([stored])
    return {"ok": True}


@app.get("/api/attachments/{att_id}/file", dependencies=[Depends(auth)])
def get_file(att_id: int):
    att = db.get_attachment(att_id)
    if att is None:
        raise HTTPException(status_code=404, detail="附件不存在")
    return FileResponse(
        os.path.join(config.FILES_DIR, att["stored_name"]),
        media_type=att["mime"],
        filename=att["filename"],
    )


@app.get("/api/attachments/{att_id}/thumb", dependencies=[Depends(auth)])
def get_thumb(att_id: int):
    att = db.get_attachment(att_id)
    if att is None or not att["has_thumb"]:
        raise HTTPException(status_code=404, detail="缩略图不存在")
    return FileResponse(
        os.path.join(config.THUMBS_DIR, att["stored_name"] + ".jpg"),
        media_type="image/jpeg",
    )
