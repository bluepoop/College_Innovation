"""SQLite 数据访问层：entries 表 + FTS5 全文索引 + attachments 表。

FTS5 的 unicode61 分词器不会切分中文，所以索引和查询前
都先把每个 CJK 字符用空格隔开（单字分词），实现中文模糊检索。
"""

import re
import sqlite3
import threading
from datetime import datetime, timezone

from . import config

# 所有读写共用一把可重入锁：FastAPI 在线程池中执行接口，
# 多线程并发使用同一个 SQLite 连接会偶发 InterfaceError
_lock = threading.RLock()
_conn = None

_SCHEMA = """
CREATE TABLE IF NOT EXISTS entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE VIRTUAL TABLE IF NOT EXISTS entries_fts USING fts5(text);
CREATE TABLE IF NOT EXISTS attachments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_id INTEGER NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
    filename TEXT NOT NULL,
    mime TEXT NOT NULL,
    size INTEGER NOT NULL,
    stored_name TEXT NOT NULL,
    has_thumb INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_attachments_entry ON attachments(entry_id);
"""

_CJK_RE = re.compile(r"([\u2e80-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af])")


def segment(text):
    """把 CJK 字符逐个用空格隔开，供 FTS5 索引/查询使用。"""
    return _CJK_RE.sub(r" \1 ", text)


def _now():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def init():
    global _conn
    import os

    os.makedirs(config.FILES_DIR, exist_ok=True)
    os.makedirs(config.THUMBS_DIR, exist_ok=True)
    _conn = sqlite3.connect(config.DB_PATH, check_same_thread=False)
    _conn.row_factory = sqlite3.Row
    _conn.execute("PRAGMA journal_mode=WAL")
    _conn.execute("PRAGMA foreign_keys=ON")
    with _conn:
        _conn.executescript(_SCHEMA)


def create_entry(text):
    now = _now()
    with _lock, _conn:
        cur = _conn.execute(
            "INSERT INTO entries (text, created_at, updated_at) VALUES (?,?,?)",
            (text, now, now),
        )
        entry_id = cur.lastrowid
        _conn.execute(
            "INSERT INTO entries_fts (rowid, text) VALUES (?,?)",
            (entry_id, segment(text)),
        )
    return entry_id


def update_entry(entry_id, text):
    with _lock, _conn:
        cur = _conn.execute(
            "UPDATE entries SET text=?, updated_at=? WHERE id=?",
            (text, _now(), entry_id),
        )
        if cur.rowcount == 0:
            return False
        _conn.execute("DELETE FROM entries_fts WHERE rowid=?", (entry_id,))
        _conn.execute(
            "INSERT INTO entries_fts (rowid, text) VALUES (?,?)",
            (entry_id, segment(text)),
        )
    return True


def delete_entry(entry_id):
    with _lock, _conn:
        rows = _conn.execute(
            "SELECT stored_name FROM attachments WHERE entry_id=?", (entry_id,)
        ).fetchall()
        cur = _conn.execute("DELETE FROM entries WHERE id=?", (entry_id,))
        if cur.rowcount == 0:
            return None
        _conn.execute("DELETE FROM entries_fts WHERE rowid=?", (entry_id,))
    return [r["stored_name"] for r in rows]


def search_entries(query, limit=50, offset=0):
    """query 为空时按更新时间倒序列出全部，否则走 FTS5。"""
    if query:
        sql = (
            "SELECT e.* FROM entries e JOIN entries_fts f ON e.id = f.rowid "
            "WHERE entries_fts MATCH ? ORDER BY e.updated_at DESC LIMIT ? OFFSET ?"
        )
        # 加引号做短语匹配，避免特殊字符触发 FTS5 语法错误
        args = ('"' + segment(query).replace('"', "") + '"', limit, offset)
    else:
        sql = "SELECT * FROM entries ORDER BY updated_at DESC LIMIT ? OFFSET ?"
        args = (limit, offset)
    with _lock:
        return _conn.execute(sql, args).fetchall()


def get_entry(entry_id):
    with _lock:
        return _conn.execute("SELECT * FROM entries WHERE id=?", (entry_id,)).fetchone()


def add_attachment(entry_id, filename, mime, size, stored_name, has_thumb):
    with _lock, _conn:
        cur = _conn.execute(
            "INSERT INTO attachments (entry_id, filename, mime, size, stored_name, has_thumb, created_at)"
            " VALUES (?,?,?,?,?,?,?)",
            (entry_id, filename, mime, size, stored_name, int(has_thumb), _now()),
        )
        _conn.execute("UPDATE entries SET updated_at=? WHERE id=?", (_now(), entry_id))
    return cur.lastrowid


def get_attachment(att_id):
    with _lock:
        return _conn.execute(
            "SELECT * FROM attachments WHERE id=?", (att_id,)
        ).fetchone()


def list_attachments(entry_id):
    with _lock:
        return _conn.execute(
            "SELECT * FROM attachments WHERE entry_id=? ORDER BY id", (entry_id,)
        ).fetchall()


def delete_attachment(att_id):
    with _lock, _conn:
        row = get_attachment(att_id)
        if row is None:
            return None
        _conn.execute("DELETE FROM attachments WHERE id=?", (att_id,))
    return row["stored_name"]


def set_thumb(att_id):
    with _lock, _conn:
        _conn.execute("UPDATE attachments SET has_thumb=1 WHERE id=?", (att_id,))
