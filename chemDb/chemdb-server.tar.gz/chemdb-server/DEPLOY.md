# chemDb 服务端部署指南

本文档面向自动化部署 agent，按顺序执行即可完成部署。
目标系统：Debian/Ubuntu 系 Linux（其它发行版替换包管理命令即可）。

## 包内容

- `app/` — FastAPI 服务端源码（无需修改）
- `requirements.txt` — Python 依赖：fastapi / uvicorn / pillow / python-multipart
- `run.sh` — 手动启动脚本（前台运行，调试用）
- `chemdb.service` — systemd 服务模板（**需要根据实际路径和用户修改**）
- `chemdb_demo_key.pub` — 客户端内置 SSH 私钥对应的公钥

## 部署变量（先确定好）

- `DEPLOY_DIR`：安装目录，例如 `/home/<USER>/chemdb-server`
- `USER`：运行服务、同时也是客户端 SSH 登录用的系统用户名
- `TOKEN`：API 鉴权 token，自定义一串随机字符串，
  必须与客户端 `config.py` 的 `API_TOKEN` 一致

## 步骤

### 1. 解压并安装依赖

```bash
tar xzf chemdb-server.tar.gz -C ~          # 得到 ~/chemdb-server
cd ~/chemdb-server

sudo apt update
sudo apt install -y python3 python3-venv   # Python 要求 3.10+

python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
```

### 2. 授权客户端 SSH 登录

客户端通过 SSH（经 SakuraFRP TCP 隧道转发到本机 22 端口）连接，
把包里带的公钥加入部署用户的 authorized_keys：

```bash
mkdir -p ~/.ssh && chmod 700 ~/.ssh
cat ~/chemdb-server/chemdb_demo_key.pub >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
```

注意：客户端 config.py 里的 `SSH_USER` 必须等于这里的部署用户名。
可选加固：在 authorized_keys 该行最前面加
`permitopen="127.0.0.1:8000",no-pty,no-agent-forwarding,no-X11-forwarding `
使该 key 只能转发到 8000 端口。

### 3. 配置 systemd 服务

编辑 `chemdb.service`，检查三处：

- `User=` 改为部署用户名
- `WorkingDirectory=`、`ExecStart=`、`CHEMDB_DATA=` 中的路径改为实际 `DEPLOY_DIR`
- `Environment=CHEMDB_TOKEN=` 改为确定的 TOKEN

然后安装并启动：

```bash
sudo cp chemdb.service /etc/systemd/system/chemdb.service
sudo systemctl daemon-reload
sudo systemctl enable --now chemdb
```

### 4. 验证

```bash
systemctl status chemdb                     # 应为 active (running)
curl -H "Authorization: Bearer <TOKEN>" http://127.0.0.1:8000/api/health
# 期望输出: {"ok":true}
```

### 5. SakuraFRP

建一条 TCP 隧道：本地地址 `127.0.0.1`，本地端口 `22`。
把分配到的地址和端口填进客户端 `config.py` 的 `SSH_HOST` / `SSH_PORT`。

## 运维命令

- 重启：`sudo systemctl restart chemdb`
- 日志：`journalctl -u chemdb -f`
- 停止：`sudo systemctl stop chemdb`

## 数据说明

首次启动自动创建 `data/` 目录（SQLite 库、附件、缩略图），无需预置。
备份直接拷贝整个 `data/` 目录。

## 资源占用

Python 3 + uvicorn + SQLite，实测内存约 55MB；service 中已设 `MemoryMax=512M`。
